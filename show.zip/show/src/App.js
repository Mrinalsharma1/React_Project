import logo from './logo.svg';
import './App.css';
import Show from './show';
function App() {
  return (
  <Show/>
  );
}

export default App;
